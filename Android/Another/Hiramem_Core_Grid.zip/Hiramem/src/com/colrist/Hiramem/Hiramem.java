package com.colrist.Hiramem;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

public class Hiramem extends Activity {

    public int maxProcess = 0;

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        // Resize control panel height to match screen
        int height = getWindowManager().getDefaultDisplay().getWidth() / 3;
        LinearLayout controlPanel = (LinearLayout)findViewById(R.id.controlPanel);
        controlPanel.getLayoutParams().height = height;
        controlPanel.requestLayout();

        // resize cell height to match screen
        int cheight = getWindowManager().getDefaultDisplay().getWidth() / 5;
        LinearLayout cellPack = (LinearLayout)findViewById(R.id.cellPack);
        cellPack.getLayoutParams().height = cheight;
        cellPack.requestLayout();

        // Calculate max amount of visible cells
        maxProcess = 5 * ((getWindowManager().getDefaultDisplay().getHeight() - height) / cheight + 1);

        // Filter the cell list, remove unused cells
        if (!GlobalVars.buttonList.isEmpty()) {
            int cnt = GlobalVars.buttonList.size() - 1;
            while (cnt >= maxProcess) {
                GlobalVars.buttonList.get(cnt).Enabled = false;
                GlobalVars.buttonList.remove(cnt);
                cnt = GlobalVars.buttonList.size() - 1;
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: {
                // Close all cells
                if (!GlobalVars.buttonList.isEmpty()) {
                    for (int i = 0; i < GlobalVars.buttonList.size(); i++) {
                        if (i < maxProcess) {
                            GlobalVars.buttonList.get(i).isSelected = false;
                            GlobalVars.buttonList.get(i).invalidate();
                        }
                    }
                }
                // Open only current cell
                if (GlobalVars.currentClick != null) {
                    GlobalVars.currentClick.isSelected = true;
                    GlobalVars.currentClick.invalidate();
                }
            } break;
        }
        return super.onTouchEvent(event);    //To change body of overridden methods use File | Settings | File Templates.
    }
}
