package com.colrist.Hiramem;

import java.util.ArrayList;

/**
 * Created with IntelliJ IDEA.
 * User: King
 * Date: 23/03/2013
 * Time: 10:19
 * To change this template use File | Settings | File Templates.
 */
public class GlobalVars {
    public static ArrayList<HiraButton> buttonList = new ArrayList<HiraButton>();
    public static HiraButton currentClick = null;
}
