package com.colrist.Hiramem;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created with IntelliJ IDEA.
 * User: King
 * Date: 23/03/2013
 * Time: 09:17
 */
public class HiraButton extends View {

    public String text = "A";
    public Boolean isSelected = false;
    public Boolean Enabled = true;

    public HiraButton(Context context) {
        super(context);
        GlobalVars.buttonList.add(this);
    }

    public HiraButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        GlobalVars.buttonList.add(this);
    }

    public HiraButton(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        GlobalVars.buttonList.add(this);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (Enabled) {
            Paint p = new Paint();
            if (!isSelected) {
                p.setColor(Color.parseColor("#3773D2"));
                canvas.drawRect(5, 5, getWidth() - 5, getHeight() - 5, p);
            } else {
                p.setColor(Color.parseColor("#6096eb"));
                canvas.drawRect(1, 1, getWidth() - 1, getHeight() - 1, p);
                p.setColor(Color.WHITE);
                p.setTextSize(getWidth()*0.65f);
                canvas.drawText(text, getWidth() / 2 - p.measureText(text) / 2, getHeight() / 2 + p.measureText(text) / 1.5f, p);
            }
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, w, oldw, oldh);    //To change body of overridden methods use File | Settings | File Templates.
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        // TODO Auto-generated method stub
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec),
                MeasureSpec.getSize(heightMeasureSpec));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (Enabled) {
            GlobalVars.currentClick = this;
            ((Activity)getContext()).onTouchEvent(event);
            return true;
        } else return false;
    }
}
