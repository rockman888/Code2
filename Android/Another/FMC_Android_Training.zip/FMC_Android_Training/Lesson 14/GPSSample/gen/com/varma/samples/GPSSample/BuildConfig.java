/** Automatically generated file. DO NOT MODIFY */
package com.varma.samples.GPSSample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}