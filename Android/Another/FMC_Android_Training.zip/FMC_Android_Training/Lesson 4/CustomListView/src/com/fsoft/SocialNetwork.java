package com.fsoft;

public class SocialNetwork {
    public int icon;
    public String title;
    public SocialNetwork(){
        super();
    }
   
    public SocialNetwork(int icon, String title) {
        super();
        this.icon = icon;
        this.title = title;
    }
}