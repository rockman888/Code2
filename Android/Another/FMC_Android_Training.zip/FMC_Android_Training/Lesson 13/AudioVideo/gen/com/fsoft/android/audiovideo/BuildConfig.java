/** Automatically generated file. DO NOT MODIFY */
package com.fsoft.android.audiovideo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}