/** Automatically generated file. DO NOT MODIFY */
package com.varma.samples.audiorecorder;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}