/** Automatically generated file. DO NOT MODIFY */
package com.fsoft.Animation;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}