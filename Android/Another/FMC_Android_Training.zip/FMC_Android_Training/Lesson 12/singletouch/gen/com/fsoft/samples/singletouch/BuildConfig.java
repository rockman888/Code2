/** Automatically generated file. DO NOT MODIFY */
package com.fsoft.samples.singletouch;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}