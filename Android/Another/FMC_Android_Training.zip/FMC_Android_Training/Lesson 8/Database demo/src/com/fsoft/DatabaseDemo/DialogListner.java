package com.fsoft.DatabaseDemo;

import android.content.DialogInterface;

public class DialogListner implements android.content.DialogInterface.OnClickListener {

	
	public DialogListner()
	{
		
	}
	
	@Override
	public void onClick(DialogInterface dialog, int which) {
		// TODO Auto-generated method stub
		
	}

}
